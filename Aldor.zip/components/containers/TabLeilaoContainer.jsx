
// TabLeilaoContainer — container modular de aba
export default function TabLeilaoContainer({{ children }}) {{
  return <section className="space-y-3">{children}</section>;
}}
