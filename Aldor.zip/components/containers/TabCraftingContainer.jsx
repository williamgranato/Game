
// TabCraftingContainer — container modular de aba
export default function TabCraftingContainer({{ children }}) {{
  return <section className="space-y-3">{children}</section>;
}}
