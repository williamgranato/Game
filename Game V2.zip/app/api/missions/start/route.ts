import { NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';

export async function POST(req: Request) {
  const body = await req.json();
  const { missionId, durationMin, staminaCost, rank } = body || {};
  if (!missionId || !durationMin || staminaCost == null) {
    return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
  }

  // TODO auth: por enquanto usamos um player fixo/local
  const playerId = 'local-player';

  // upsert player
  let player = await prisma.player.upsert({
    where: { id: playerId },
    update: {},
    create: { id: playerId, name: 'Aventureiro' },
  });

  if (player.stamina < Number(staminaCost)) {
    return NextResponse.json({ error: 'Sem stamina suficiente' }, { status: 400 });
  }

  // consume stamina
  player = await prisma.player.update({
    where: { id: playerId },
    data: { stamina: { decrement: Number(staminaCost) } },
  });

  const endsAt = new Date(Date.now() + Number(durationMin) * 60 * 1000);
  const progress = await prisma.missionProgress.create({
    data: {
      playerId,
      missionId,
      rank: String(rank || 'F'),
      endsAt,
    },
  });

  return NextResponse.json({ ok: true, progress, player });
}
