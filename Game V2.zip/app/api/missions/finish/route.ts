import { NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';
import { MONSTERS } from '../../../../data/monsters';
import { RANKS } from '../../../../data/ranks';

function randomPick<T>(arr: T[]): T { return arr[Math.floor(Math.random()*arr.length)]; }
function rollChance(p: number){ return Math.random() < p; }

export async function POST(req: Request) {
  const body = await req.json();
  const { missionId } = body || {};
  if (!missionId) {
    return NextResponse.json({ error: 'Missing missionId' }, { status: 400 });
  }

  const playerId = 'local-player';
  const progress = await prisma.missionProgress.findFirst({
    where: { playerId, missionId, completed: false },
  });
  if (!progress) return NextResponse.json({ error: 'Missão não encontrada/ativa' }, { status: 404 });

  const now = new Date();
  if (now < progress.endsAt) {
    return NextResponse.json({ error: 'Missão ainda em progresso' }, { status: 400 });
  }

  const rank = String(progress.rank || 'F');

  const poolChance: Record<string, number> = { 'F':0.6, 'E':0.6, 'D':0.5, 'C':0.45, 'B':0.35, 'A':0.28, 'S':0.22, 'SS':0.18 };
  const epicChance: Record<string, number> = { 'F':0.00, 'E':0.00, 'D':0.02, 'C':0.04, 'B':0.06, 'A':0.10, 'S':0.14, 'SS':0.18 };
  const legendChance: Record<string, number> = { 'F':0.00, 'E':0.00, 'D':0.00, 'C':0.00, 'B':0.01, 'A':0.02, 'S':0.03, 'SS':0.05 };

  const order = ['F','E','D','C','B','A','S','SS'];
  const pool = MONSTERS.filter(m => order.indexOf(m.rank as any) <= order.indexOf(rank as any));
  const mob = randomPick(pool);

  const drops: { item: string, qty: number }[] = [];
  if (rollChance(poolChance[rank as any])) drops.push({ item: randomPick(mob.drops), qty: 1 });
  if (rollChance(epicChance[rank as any])) drops.push({ item: 'Item Épico Misterioso', qty: 1 });
  if (rollChance(legendChance[rank as any])) drops.push({ item: 'Artefato Lendário', qty: 1 });

  const baseSilver: Record<string, number> = { 'F':6,'E':10,'D':16,'C':25,'B':40,'A':60,'S':90,'SS':140 };
  const baseExp: Record<string, number> = { 'F':30,'E':60,'D':90,'C':140,'B':220,'A':320,'S':520,'SS':900 };
  const repGain = (rank==='S' ? 3 : rank==='SS' ? 4 : 1);

  await prisma.missionProgress.update({
    where: { id: progress.id },
    data: { completed: true },
  });

  await prisma.player.update({
    where: { id: playerId },
    data: {
      silver: { increment: baseSilver[rank as any] || 0 },
      exp: { increment: baseExp[rank as any] || 0 },
      reputation: { increment: repGain },
    },
  });

  // read back and handle potential level ups
  let current = await prisma.player.findUnique({ where: { id: playerId } });
  if (current) {
    let exp = current.exp;
    let level = current.level;
    const expNeeded = () => 100 + level * 50;
    while (exp >= expNeeded()) { exp -= expNeeded(); level += 1; }
    if (level !== current.level || exp !== current.exp) {
      await prisma.player.update({ where: { id: playerId }, data: { level, exp } });
    }
  }

  for (const d of drops) {
    await prisma.inventoryItem.upsert({
      where: { playerId_item: { playerId, item: d.item } },
      update: { qty: { increment: d.qty } },
      create: { playerId, item: d.item, qty: d.qty },
    });
  }

  const fresh = await prisma.player.findUnique({ where: { id: playerId } });
  return NextResponse.json({ ok: true, rewards: { silver: baseSilver[rank as any], exp: baseExp[rank as any], reputation: repGain }, drops, player: fresh });
}
