import '../styles/globals.css';
import AldoriaGuilds from '../components/AldoriaGuilds';
export default function Page(){ return <AldoriaGuilds/>; }