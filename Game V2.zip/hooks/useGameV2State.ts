'use client';
import { useEffect, useState } from 'react';
import type { Rank } from '../data/ranks';
import { rankFromReputation } from '../data/ranks';
import { MONSTERS } from '../data/monsters';

export type Wallet = { gold:number; silver:number; bronze:number; copper:number };
export type Player = { name:string; level:number; exp:number; stamina:number; reputation:number; vipUntil?: number|null; };
export type AuctionLot = { id:string; item:string; qty:number; price:{gold?:number; silver?:number; bronze?:number; copper?:number}; seller:string; expiresAt:number };
export type ActiveMission = { missionId:string; endsAt:number; rank?: Rank };

const DEFAULT_STATE = {
  player: { name:'Aventureiro', level:1, exp:0, stamina:100, reputation:0, vipUntil:null } as Player,
  wallet: { gold:0, silver:50, bronze:0, copper:0 } as Wallet,
  skills: {} as Record<string, number>,
  auction: [] as AuctionLot[],
  activeMissions: [] as ActiveMission[],
  inventory: {} as Record<string, number>,
  logs: [] as string[]
};

function randomPick<T>(arr:T[]): T { return arr[Math.floor(Math.random()*arr.length)]; }
function rollChance(p:number){ return Math.random() < p; }

export function useGameV2State(){
  const [state,setState]=useState<typeof DEFAULT_STATE>(DEFAULT_STATE);

  useEffect(()=>{
    const raw = localStorage.getItem('game_v2_state');
    if(raw){ try{ setState(JSON.parse(raw)); }catch{} }
  },[]);
  useEffect(()=>{
    localStorage.setItem('game_v2_state', JSON.stringify(state));
  },[state]);

  function addLog(msg:string){
    setState(s=>({
      ...s,
      logs:[`[${new Date().toLocaleTimeString()}] ${msg}`, ...s.logs].slice(0,100)
    }));
  }

  function spendStamina(n:number){
    if(state.player.stamina<n) return false;
    setState(s=>({...s, player:{...s.player, stamina:s.player.stamina-n}}));
    return true;
  }

  function addMoney(delta:Partial<Wallet>){
    setState(s=>({
      ...s,
      wallet:{
        gold:(s.wallet.gold||0)+(delta.gold||0),
        silver:(s.wallet.silver||0)+(delta.silver||0),
        bronze:(s.wallet.bronze||0)+(delta.bronze||0),
        copper:(s.wallet.copper||0)+(delta.copper||0)
      }
    }));
  }

  function addExp(n:number){
    setState(s=>{
      let level=s.player.level, exp=s.player.exp+n;
      while(exp>=100+level*50){ exp -= (100+level*50); level++; }
      return {...s, player:{...s.player, exp, level}};
    });
  }

  function addItem(name:string, qty:number){
    setState(s=>({
      ...s,
      inventory:{...s.inventory, [name]:(s.inventory[name]||0)+qty}
    }));
  }

  function upgradeSkill(id:string, cost:number){
    if(state.wallet.silver < cost) return false;
    setState(s=>({
      ...s,
      wallet:{...s.wallet, silver:s.wallet.silver-cost},
      skills:{...s.skills, [id]:(s.skills[id]||0)+1}
    }));
    addLog(`Habilidade ${id} melhorada.`);
    return true;
  }

  function startMission(missionId:string, durationMin:number, staminaCost:number, rank?:Rank){
    if(!spendStamina(staminaCost)) return false;
    const endsAt = Date.now()+durationMin*60*1000;
    setState(s=>({
      ...s,
      activeMissions:[...s.activeMissions, {missionId, endsAt, rank: rank || rankFromReputation(s.player.reputation)}]
    }));
    addLog(`Missão ${missionId} iniciada.`);
    return true;
  }

  function finishMission(missionId:string, rewards:any){
    const am = state.activeMissions.find(m=>m.missionId===missionId);
    if(!am) return;
    setState(s=>({
      ...s,
      activeMissions:s.activeMissions.filter(m=>m.missionId!==missionId)
    }));
    if(rewards.gold) addMoney({gold:rewards.gold});
    if(rewards.silver) addMoney({silver:rewards.silver});
    if(rewards.bronze) addMoney({bronze:rewards.bronze});
    if(rewards.copper) addMoney({copper:rewards.copper});
    if(rewards.exp) addExp(rewards.exp);

    const repGain = (rewards.reputation || 0) + (am.rank==='S' ? 2 : am.rank==='SS' ? 3 : 1);
    setState(s=>({...s, player:{...s.player, reputation:s.player.reputation+repGain}}));

    const poolRanks: Record<string, number> = { 'F':0.6, 'E':0.6, 'D':0.5, 'C':0.45, 'B':0.35, 'A':0.28, 'S':0.22, 'SS':0.18 };
    const epicChance: Record<string, number> = { 'F':0.00, 'E':0.00, 'D':0.02, 'C':0.04, 'B':0.06, 'A':0.10, 'S':0.14, 'SS':0.18 };
    const legendChance: Record<string, number> = { 'F':0.00, 'E':0.00, 'D':0.00, 'C':0.00, 'B':0.01, 'A':0.02, 'S':0.03, 'SS':0.05 };
    const rank = am.rank || 'F';
    const order = ['F','E','D','C','B','A','S','SS'];
    const pool = MONSTERS.filter(m=> order.indexOf(m.rank) <= order.indexOf(rank));
    const mob = randomPick(pool);

    if(rollChance(poolRanks[rank])) addItem(randomPick(mob.drops), 1);
    if(rollChance(epicChance[rank])) addItem('Item Épico Misterioso', 1);
    if(rollChance(legendChance[rank])) addItem('Artefato Lendário', 1);

    addLog(`Missão ${missionId} concluída! Recompensas entregues.`);
  }

  function listActive(){ return state.activeMissions; }

  function addAuction(lot:AuctionLot){
    setState(s=>({
      ...s,
      auction:[lot, ...s.auction]
    }));
  }

  function buyAuction(id:string){
    setState(s=>({
      ...s,
      auction:s.auction.filter(a=>a.id!==id)
    }));
    addLog(`Lote ${id} comprado.`);
  }

  function playerRank(): Rank {
    return rankFromReputation(state.player.reputation);
  }

  async function startMissionServer(missionId:string, durationMin:number, staminaCost:number, rank?:Rank){
    try{
      const res = await fetch('/api/missions/start', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ missionId, durationMin, staminaCost, rank }) });
      if(!res.ok) throw new Error('start failed');
      const data = await res.json();
      const endsAt = new Date(data.progress.endsAt).getTime();
      setState(s=>({
        ...s,
        player:{...s.player, stamina:data.player.stamina},
        activeMissions:[...s.activeMissions, { missionId, endsAt, rank }]
      }));
      addLog(`Missão ${missionId} iniciada (server).`);
      return true;
    }catch(e){
      return startMission(missionId, durationMin, staminaCost, rank);
    }
  }

  async function finishMissionServer(missionId:string, rewards:any){
    try{
      const res = await fetch('/api/missions/finish', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ missionId }) });
      if(!res.ok) throw new Error('finish failed');
      const data = await res.json();
      setState(s=>({
        ...s,
        activeMissions:s.activeMissions.filter(m=>m.missionId!==missionId)
      }));
      if(data.rewards?.silver) addMoney({silver:data.rewards.silver});
      if(data.rewards?.gold) addMoney({gold:data.rewards.gold});
      if(data.rewards?.exp) addExp(data.rewards.exp);
      if(data.rewards?.reputation) setState(s=>({...s, player:{...s.player, reputation:s.player.reputation+data.rewards.reputation}}));
      if(Array.isArray(data.drops)){ data.drops.forEach((d:any)=>addItem(d.item, d.qty)); }
      addLog(`Missão ${missionId} concluída (server).`);
      return true;
    }catch(e){
      finishMission(missionId, rewards);
      return true;
    }
  }

  return {
    state, setState,
    addLog, addMoney, addExp, addItem,
    upgradeSkill, startMission, finishMission,
    listActive, addAuction, buyAuction,
    playerRank, startMissionServer, finishMissionServer
  };
}
