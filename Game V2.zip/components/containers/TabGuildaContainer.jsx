
// TabGuildaContainer — container modular de aba
export default function TabGuildaContainer({{ children }}) {{
  return <section className="space-y-3">{children}</section>;
}}
