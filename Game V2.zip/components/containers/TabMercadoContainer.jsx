
// TabMercadoContainer — container modular de aba
export default function TabMercadoContainer({{ children }}) {{
  return <section className="space-y-3">{children}</section>;
}}
